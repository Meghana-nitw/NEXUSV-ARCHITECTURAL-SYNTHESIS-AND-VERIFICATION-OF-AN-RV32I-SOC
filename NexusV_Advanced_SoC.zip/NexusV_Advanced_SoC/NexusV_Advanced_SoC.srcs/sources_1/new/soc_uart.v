`timescale 1ns / 1ps
`include "soc_defs.v"

(* dont_touch = "true" *)
module soc_uart (
    input wire         clk,
    input wire         resetn,
    input wire         en,
    input wire [1:0]   reg_offset,
    input wire [3:0]   wstrb,
    input wire [31:0]  din,
    output reg [31:0]  dout,
    output reg         ready,
    input wire         uart_rx,
    output reg         uart_tx
);

    reg [7:0]  tx_data;
    reg        tx_start;
    reg        tx_busy;
    reg [3:0]  tx_bit_cnt;
    reg [9:0]  baud_divider;
    reg [7:0]  tx_shift_reg;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            uart_tx      <= 1'b1;
            tx_data      <= 8'h0;
            tx_start     <= 1'b0;
            tx_busy      <= 1'b0;
            tx_bit_cnt   <= 4'h0;
            baud_divider <= 10'h0;
            tx_shift_reg <= 8'h0;
            dout         <= 32'h0;
            ready        <= 1'b0;
        end else begin
            ready    <= 1'b0;
            tx_start <= 1'b0;

            if (en) begin
                ready <= 1'b1;
                if (|wstrb) begin
                    if ((reg_offset == `REG_UART_DATA) && !tx_busy) begin
                        tx_data  <= din[7:0];
                        tx_start <= 1'b1;
                    end
                end else begin
                    if (reg_offset == `REG_UART_DATA) begin
                        dout <= 32'h0; 
                    end else if (reg_offset == `REG_UART_STAT) begin
                        dout <= {31'h0, tx_busy};
                    end else begin
                        dout <= 32'h0;
                    end
                end
            end

            if (tx_start && !tx_busy) begin
                tx_busy      <= 1'b1;
                tx_shift_reg <= tx_data;
                tx_bit_cnt   <= 4'd0;
                baud_divider <= 10'd0;
                uart_tx      <= 1'b0; 
            end else if (tx_busy) begin
                if (baud_divider == 10'd867) begin
                    baud_divider <= 10'd0;
                    if (tx_bit_cnt < 4'd8) begin
                        uart_tx      <= tx_shift_reg;
                        tx_shift_reg <= {1'b0, tx_shift_reg[7:1]};
                        tx_bit_cnt   <= tx_bit_cnt + 1;
                    end else if (tx_bit_cnt == 4'd8) begin
                        uart_tx    <= 1'b1; 
                        tx_bit_cnt <= tx_bit_cnt + 1;
                    end else begin
                        tx_busy <= 1'b0;
                    end
                end else begin
                    baud_divider <= baud_divider + 1;
                end
            end
        end
    end
endmodule
