`timescale 1ns / 1ps

(* dont_touch = "true" *)
module soc_ram (
    input wire         clk,
    input wire         en,
    input wire [3:0]   wstrb,
    input wire [12:0]  addr,
    input wire [31:0]  din,
    output reg [31:0]  dout
);

    (* ram_style = "block" *) reg [31:0] hardware_sram_matrix [0:8191];

    initial begin
        $readmemh("firmware.hex", hardware_sram_matrix);
    end

    always @(posedge clk) begin
        if (en) begin
            if (wstrb) hardware_sram_matrix[addr][7:0]   <= din[7:0];
            if (wstrb) hardware_sram_matrix[addr][15:8]  <= din[15:8];
            if (wstrb) hardware_sram_matrix[addr][23:16] <= din[23:16];
            if (wstrb) hardware_sram_matrix[addr][31:24] <= din[31:24];
            dout <= hardware_sram_matrix[addr];
        end
    end
endmodule
