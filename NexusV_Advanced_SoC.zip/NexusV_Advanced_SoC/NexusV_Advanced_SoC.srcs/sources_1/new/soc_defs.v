`timescale 1ns / 1ps

// ====================================================================
// SYSTEM REGISTRY HARDWARE ADDRESSING SPACE MEMORY MAP BOUNDARIES
// ====================================================================
`define RAM_BASE_ADDR   32'h0000_0000
`define RAM_HIGH_ADDR   32'h0000_7FFF // 32KB On-Chip Storage Layer

`define UART_BASE_ADDR  32'h0000_9000
`define UART_HIGH_ADDR  32'h0000_900F // 16-Byte Register Addressing Range

`define I2C_BASE_ADDR   32'h0000_A000
`define I2C_HIGH_ADDR   32'h0000_A00F // 16-Byte Register Addressing Range

// ====================================================================
// CORE PROCESSOR RECOVERY MACHINE INSTRUCTION CODES
// ====================================================================
`define SYSTEM_NOP      32'h0000_0013 // Standard RV32I No-Operation Code
`define SYSTEM_HALT     32'h0000_007F // Simulation Runtime Verification Break Hook

// ====================================================================
// SUBSYSTEM REGISTRY INDEXING MAPPING OFFSETS
// ====================================================================
`define REG_UART_DATA   2'b00         // Data Buffer Register Offset
`define REG_UART_STAT   2'b01         // Hardware Transmit Status Offset

`define REG_I2C_ADDR    2'b00         // Telemetry Target Address Offset
`define REG_I2C_DATA    2'b01         // Telemetry Active Buffer Offset
`define REG_I2C_CTRL    2'b10         // Telemetry Waveform Control Offset
