`timescale 1ns / 1ps
`include "soc_defs.v"

(* dont_touch = "true" *)
module rv32i_core (
    input wire         clk,
    input wire         resetn,
    output reg         mem_valid,
    output reg [31:0]  mem_addr,
    output reg [3:0]   mem_wstrb,
    output reg [31:0]  mem_wdata,
    input wire [31:0]  mem_rdata,
    input wire         mem_ready
);

    reg [31:0] pc;
    reg [31:0] GPR_file [0:31];
    reg [1:0]  pipeline_state;
    integer i;

    localparam STATE_FETCH   = 2'b00;
    localparam STATE_WAIT    = 2'b01;
    localparam STATE_EXECUTE = 2'b10;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            pc             <= `RAM_BASE_ADDR;
            mem_valid      <= 1'b0;
            mem_addr       <= 32'h0;
            mem_wstrb      <= 4'b0000;
            mem_wdata      <= 32'h0;
            pipeline_state <= STATE_FETCH;
            for (i = 0; i < 32; i = i + 1) GPR_file[i] <= 32'h0;
        end else begin
            case (pipeline_state)
                STATE_FETCH: begin
                    mem_valid      <= 1'b1;
                    mem_addr       <= pc;
                    mem_wstrb      <= 4'b0000; 
                    pipeline_state <= STATE_WAIT;
                end

                STATE_WAIT: begin
                    if (mem_ready) begin
                        mem_valid      <= 1'b0;
                        pipeline_state <= STATE_EXECUTE;
                    end
                end

                STATE_EXECUTE: begin
                    if (mem_rdata == `SYSTEM_HALT) begin
                        pc             <= `RAM_BASE_ADDR;
                        pipeline_state <= STATE_FETCH;
                    end else begin
                        pc             <= pc + 4; 
                        pipeline_state <= STATE_FETCH; 
                        
                        if (mem_rdata[6:0] == 7'h33) begin
                            GPR_file[mem_rdata[11:7]] <= GPR_file[mem_rdata[19:15]] + GPR_file[mem_rdata[24:20]];
                        end else if (mem_rdata[6:0] == 7'h13) begin
                            GPR_file[mem_rdata[11:7]] <= GPR_file[mem_rdata[19:15]] + mem_rdata[31:20];
                        end
                    end
                end
                default: pipeline_state <= STATE_FETCH;
            endcase
        end
    end
endmodule
