`timescale 1ns / 1ps
`include "soc_defs.v"

(* dont_touch = "true" *)
module soc_interconnect (
    input wire [31:0]  cpu_addr,
    input wire         cpu_valid,
    input wire [3:0]   cpu_wstrb,
    input wire [31:0]  cpu_wdata,
    output reg [31:0]  cpu_rdata,
    output reg         cpu_ready,

    output reg         sel_ram,
    output reg         sel_uart,
    output reg         sel_i2c,

    input wire [31:0]  ram_rdata,
    input wire [31:0]  uart_rdata,
    input wire         uart_ready,
    input wire [31:0]  i2c_rdata,
    input wire         i2c_ready
);

    always @(*) begin
        sel_ram   = 1'b0;
        sel_uart  = 1'b0;
        sel_i2c   = 1'b0;
        cpu_rdata = 32'h0;
        cpu_ready = 1'b0;

        if (cpu_valid) begin
            if (cpu_addr >= `RAM_BASE_ADDR && cpu_addr <= `RAM_HIGH_ADDR) begin
                sel_ram   = 1'b1;
                cpu_rdata = ram_rdata;
                cpu_ready = 1'b1;
            end 
            else if (cpu_addr >= `UART_BASE_ADDR && cpu_addr <= `UART_HIGH_ADDR) begin
                sel_uart  = 1'b1;
                cpu_rdata = uart_rdata;
                cpu_ready = uart_ready;
            end
            else if (cpu_addr >= `I2C_BASE_ADDR && cpu_addr <= `I2C_HIGH_ADDR) begin
                sel_i2c   = 1'b1;
                cpu_rdata = i2c_rdata;
                cpu_ready = i2c_ready;
            end
        end
    end
endmodule
