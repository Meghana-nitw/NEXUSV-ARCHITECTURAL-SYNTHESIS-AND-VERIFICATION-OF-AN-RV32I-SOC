`timescale 1ns / 1ps
`include "soc_defs.v"

(* dont_touch = "true" *)
module soc_i2c (
    input wire         clk,
    input wire         resetn,
    input wire         en,
    input wire [1:0]   reg_offset,
    input wire [3:0]   wstrb,
    input wire [31:0]  din,
    output reg [31:0]  dout,
    output reg         ready,
    inout wire         i2c_sda,
    output reg         i2c_scl
);

    reg [7:0] slave_addr;
    reg [7:0] data_reg;
    reg       i2c_direction; 
    reg       sda_out;
    
    assign i2c_sda = i2c_direction ? sda_out : 1'bz;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            i2c_scl       <= 1'b1;
            sda_out       <= 1'b1;
            i2c_direction <= 1'b0;
            slave_addr    <= 8'h0;
            data_reg      <= 8'h0;
            ready         <= 1'b0;
            dout          <= 32'h0;
        end else begin
            ready <= 1'b0;
            if (en) begin
                ready <= 1'b1;
                if (|wstrb) begin
                    if (reg_offset == `REG_I2C_ADDR) begin
                        slave_addr <= din[7:0];
                    end else if (reg_offset == `REG_I2C_DATA) begin
                        data_reg <= din[7:0];
                    end
                end else begin
                    if (reg_offset == `REG_I2C_ADDR) begin
                        dout <= {24'h0, slave_addr};
                    end else if (reg_offset == `REG_I2C_DATA) begin
                        dout <= {24'h0, data_reg};
                    end else begin
                        dout <= 32'h0;
                    end
                end
            end
        end
    end
endmodule
