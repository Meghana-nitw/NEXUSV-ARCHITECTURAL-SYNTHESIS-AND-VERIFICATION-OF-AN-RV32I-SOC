`timescale 1ns / 1ps

module tb_nexusv_top();
    reg  clk;
    reg  resetn;
    reg  uart_rx;
    wire uart_tx;
    wire i2c_sda;
    wire i2c_scl;

    assign i2c_sda = 1'bz; 

    nexusv_top uut (
        .clk(clk), .resetn(resetn),
        .uart_rx(uart_rx), .uart_tx(uart_tx),
        .i2c_sda(i2c_sda), .i2c_scl(i2c_scl)
    );

    always #5 clk = ~clk;

    initial begin
        clk     = 0;
        resetn  = 0;
        uart_rx = 1;

        $display("[SIMULATION INITIALIZED] Starting simulation environment execution layout...");
        #100;
        resetn  = 1; 
        $display("[SIMULATION HARDWARE RESET] Global reset line released successfully.");

        #10000;
        $display("[SIMULATION COMPLETION] Testing sweep complete.");
        $finish;
    end
endmodule
